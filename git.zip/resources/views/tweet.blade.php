@extends('layouts.app')
@section('content')
	<div class="container">
		@include('layouts.postForm')
	</div>
@endsection